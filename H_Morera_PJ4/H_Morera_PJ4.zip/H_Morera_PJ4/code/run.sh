#!/bin/bash
./tsai test_1.txt
./tsai test_2.txt
./tsai test_3.txt