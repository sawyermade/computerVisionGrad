#!/bin/bash
python homography_2020.py -s configs/source/cokeBigSS.conf -t configs/target/stopSign.conf -o output/stopSign_cokeBig.png
