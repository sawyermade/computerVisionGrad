# Assignment 3 Homography
## Run:
```
$ python3 projection.py fromImgConf toImgConf outFile dampening
```
