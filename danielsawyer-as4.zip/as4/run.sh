#!/bin/bash
cd src
bash compile.sh
./a.out ../pics/img2.txt
rm ./a.out
