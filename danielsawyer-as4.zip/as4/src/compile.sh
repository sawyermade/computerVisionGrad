#!/bin/bash
gcc *.c -lm
