# Assignment 4 Camera Calibration

## Run:
```
bash run.sh
```
